import 'package:flutter/material.dart';

class MyCustomBottomNavBar extends StatefulWidget {
  @override
  _MyCustomBottomNavBarState createState() => _MyCustomBottomNavBarState();
}

class _MyCustomBottomNavBarState extends State<MyCustomBottomNavBar> {
  int _currentIndex = 0;

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      // Background color of the BottomNavigationBar
      child: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: onTabTapped,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home, color: _currentIndex == 0 ? Colors.blue : Colors.grey[400]), label: 'Home', backgroundColor: Colors.red),
          BottomNavigationBarItem(
            icon: Icon(Icons.business, color: _currentIndex == 1 ? Colors.blue : Colors.grey[400]),
            label: 'Business',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.school, color: _currentIndex == 2 ? Colors.blue : Colors.grey[400]),
            label: 'School',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings, color: _currentIndex == 3 ? Colors.blue : Colors.grey[400]),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}
