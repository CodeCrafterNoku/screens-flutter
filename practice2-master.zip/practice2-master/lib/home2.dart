import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class home2 extends StatelessWidget {
  const home2({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      appBar: AppBar(
        backgroundColor: Colors.grey.shade200,
        title: Center(
          child: Text(
            "SIGN UP",
            style: TextStyle(fontWeight: FontWeight.w600),
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 18.0, bottom: 2),
            child: Icon(
              CupertinoIcons.xmark,
              size: 16,
            ),
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24.0),
        child: Column(
          children: [
            Container(
              height: 60,
              width: double.infinity,
              decoration: BoxDecoration(border: Border.all(color: Colors.black), color: Colors.white),
              child: Row(
                children: [
                  SizedBox(
                    width: 10,
                  ),
                  Icon(Icons.person),
                  SizedBox(
                    width: 10,
                  ),
                  Text("Full Name"),
                ],
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Container(
              height: 60,
              width: double.infinity,
              decoration: BoxDecoration(border: Border.all(color: Colors.black), color: Colors.white),
              child: Row(
                children: [
                  SizedBox(
                    width: 10,
                  ),
                  Icon(Icons.phone),
                  SizedBox(
                    width: 10,
                  ),
                  Text("Phone Number"),
                ],
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Container(
              height: 60,
              width: double.infinity,
              decoration: BoxDecoration(border: Border.all(color: Colors.black), color: Colors.white),
              child: Row(
                children: [
                  SizedBox(
                    width: 10,
                  ),
                  Icon(Icons.alternate_email),
                  SizedBox(
                    width: 10,
                  ),
                  Text("Email"),
                ],
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Container(
              height: 60,
              width: double.infinity,
              decoration: BoxDecoration(border: Border.all(color: Colors.black), color: Colors.white),
              child: Row(
                children: [
                  SizedBox(
                    width: 10,
                  ),
                  Icon(Icons.lock),
                  SizedBox(
                    width: 10,
                  ),
                  Text("Password"),
                  SizedBox(
                    width: 154,
                  ),
                  Icon(CupertinoIcons.eye_slash_fill),
                ],
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Container(
              height: 60,
              width: double.infinity,
              decoration: BoxDecoration(border: Border.all(color: Colors.black), color: Colors.white),
              child: Row(
                children: [
                  SizedBox(
                    width: 10,
                  ),
                  Icon(Icons.lock_outline),
                  SizedBox(
                    width: 10,
                  ),
                  Text("Confirm Password"),
                  SizedBox(
                    width: 100,
                  ),
                  Icon(CupertinoIcons.eye_slash_fill),
                ],
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Row(
              children: [
                Container(
                  height: 20,
                  width: 20,
                  decoration: BoxDecoration(border: Border.all(color: Colors.black), color: Colors.white),
                ),
                SizedBox(
                  width: 15,
                ),
                Text(
                  "Remember me",
                  style: TextStyle(fontWeight: FontWeight.w500),
                ),
              ],
            ),
            SizedBox(height: 30),
            Container(
              height: 50,
              width: 180,
              color: Colors.black,
              child: Center(
                child: Text(
                  "SIGN UP",
                  style: TextStyle(color: Colors.white, fontSize: 20),
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Text(
              "- OR -",
              style: TextStyle(fontSize: 16),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 50.0, vertical: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    height: 50,
                    width: 60,
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.black)),
                    child: Icon(
                      Icons.facebook,
                      size: 34,
                    ),
                  ),
                  Container(
                    height: 50,
                    width: 60,
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.black)),
                    child: Icon(
                      Icons.email_outlined,
                      size: 34,
                    ),
                  ),
                  Container(
                    height: 50,
                    width: 60,
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.black)),
                    child: Icon(
                      Icons.apple,
                      size: 34,
                    ),
                  )
                ],
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Row(
                children: [
                  Text(
                    "Already have an Account?",
                    style: TextStyle(fontWeight: FontWeight.w500, fontSize: 16),
                  ),
                  SizedBox(
                    width: 6,
                  ),
                  Text(
                    "SIGN IN",
                    style: TextStyle(color: Colors.red, fontWeight: FontWeight.w600, fontSize: 16),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
