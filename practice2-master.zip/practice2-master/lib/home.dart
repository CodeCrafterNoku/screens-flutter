import 'package:flutter/material.dart';
import 'package:flutter/material.dart';

import 'bottom.dart';

class home extends StatelessWidget {
  const home({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green,
      appBar: AppBar(
        backgroundColor: Colors.red,
        leading: GestureDetector(
          child: const Icon(
            Icons.menu_rounded,
            color: Colors.white,
          ),
        ),
        title: const Center(
          child: Text(
            "screen1",
          ),
        ),
        actions: [
          const Padding(
            padding: EdgeInsets.all(8.0),
            child: Icon(
              Icons.person,
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                "Hello\nNokubonga",
                style: TextStyle(fontSize: 34, fontWeight: FontWeight.w500),
              ),
            ),
            Container(
              height: 60,
              width: double.infinity,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: Colors.white),
              child: const Padding(
                padding: EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    Icon(Icons.search),
                    SizedBox(
                      width: 40,
                    ),
                    Text("Search"),
                  ],
                ),
              ),
            ),
            Container(
              height: 60,
            )
          ],
        ),
      ),
      drawer: const Drawer(),
      bottomNavigationBar: MyCustomBottomNavBar(),
    );
  }
}
